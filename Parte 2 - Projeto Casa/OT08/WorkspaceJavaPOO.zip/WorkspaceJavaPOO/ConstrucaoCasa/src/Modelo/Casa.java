package Modelo;

public class Casa {

}

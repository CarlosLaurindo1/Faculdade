package Modelo;

public class Portas extends Aberturas{}

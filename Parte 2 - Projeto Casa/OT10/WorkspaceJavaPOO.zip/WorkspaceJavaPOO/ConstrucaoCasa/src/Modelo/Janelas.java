package Modelo;

public class Janelas extends Aberturas{}

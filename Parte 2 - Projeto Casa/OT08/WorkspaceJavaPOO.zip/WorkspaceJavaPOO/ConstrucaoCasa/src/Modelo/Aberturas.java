package Modelo;

public abstract class Aberturas {

}

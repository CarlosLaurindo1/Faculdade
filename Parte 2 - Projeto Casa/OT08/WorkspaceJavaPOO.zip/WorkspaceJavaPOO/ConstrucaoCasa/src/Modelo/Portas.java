package Modelo;

public class Portas {

}
